package com.neiben.admin.controller;

import com.neiben.admin.util.WorldUtil;
import com.neiben.model.dto.order.OrderByPrint;
import com.neiben.model.dto.order.OrderDetail;
import com.neiben.model.dto.order.OrderInfoDto;
import com.neiben.model.request.OrderSearchRequest;
import com.neiben.model.response.PageResult;
import com.neiben.service.order.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class OrderController {
    @Autowired
    private OrderService orderService;

    @GetMapping("/orders")
    public PageResult<OrderInfoDto> getOrders(OrderSearchRequest orderSearchRequest){
        return orderService.getOrders(orderSearchRequest);
    }


    @GetMapping("/getOrderById")
    public OrderDetail getOrderById(Integer orderId){
        return orderService.getOrderById(orderId);
    }

    @GetMapping("/getWorld")
    public void getWorld(HttpServletResponse response,OrderSearchRequest orderSearchRequest){
        List<OrderByPrint> ordersForPrint = orderService.getOrdersForPrint(orderSearchRequest);
        Map<String,Object> map = new HashMap();
        map.put("users",ordersForPrint);
        WorldUtil.exportDoc(map,"pinmazuofan.ftl", "orders",response);
    }

}

